package com.examples.multiviewrecyclerview.DataItems

data class CoverSmallVerticalItems( val image_res : Int) {
}