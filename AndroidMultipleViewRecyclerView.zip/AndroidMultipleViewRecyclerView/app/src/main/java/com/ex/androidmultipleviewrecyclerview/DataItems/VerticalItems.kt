package com.examples.multiviewrecyclerview.DataItems

data class VerticalItems(  val imagers : Int ) {
}