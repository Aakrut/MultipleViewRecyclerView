package com.examples.multiviewrecyclerview.DataItems

data class GroupItems(var text_des : String, var more : String ) {




}