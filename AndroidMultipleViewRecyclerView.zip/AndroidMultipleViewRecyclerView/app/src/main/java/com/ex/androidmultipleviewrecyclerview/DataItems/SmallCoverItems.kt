package com.examples.multiviewrecyclerview.DataItems

data class SmallCoverItems(val images : Int) {
}